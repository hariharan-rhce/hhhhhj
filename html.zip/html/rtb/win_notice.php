<?php
//error_reporting(E_ALL);
ini_set("log_errors", 1);
ini_set("error_log", "php-error.log");
$exchange_id = (isset($_GET['exchange']) && is_numeric($_GET['exchange'])) ? $_GET['exchange'] : 0;
require_once('config.php');

$dtype = (isset($_GET['dtype']) && is_numeric($_GET['dtype'])) ? $_GET['dtype'] : 0;
$crid = (isset($_GET['crid']) && is_numeric($_GET['crid'])) ? $_GET['crid'] : 0;
$adid = (isset($_GET['adid']) && is_numeric($_GET['adid'])) ? $_GET['adid'] : 0;
$bidid = (isset($_GET['bidid'])) ? $_GET['bidid'] : NULL;
$price = (isset($_GET['price']) && is_numeric($_GET['price'])) ? $_GET['price'] : 0;
if($adid == 0 ) exit;
$cache = new Caching();
if(!$exchange = $cache->get('exchange' . $exchange_id)) {
$GLOBALS['db'] = new DB(); 
$exchange = $GLOBALS['db']->queryFetchAllAssoc('SELECT ex.exchange_id, ex.rtb_version, ex.rtb_mode, oxz.zoneid FROM ' . TAB_THIRD_PARTY_EXCHANGE . ' ex JOIN ' . TAB_ZONES . ' oxz ON ex.exchange_id = oxz.dj_is_dsp WHERE ex.status = 1 AND ex.exchange_id = ' . $exchange_id);
$cache->save('exchange' . $exchange_id, $exchange);
}
if(!$campaign = $cache->get('campaign' . $adid)) {
if(!isset($GLOBALS['db'])) $GLOBALS['db'] = new DB();
$campaign = $GLOBALS['db']->queryFetchAllAssoc('SELECT oxb.bannerid, oxc.campaignid, oxc.revenue, oxcl.clientid FROM ' . TAB_BANNERS . ' oxb JOIN ' . TAB_CAMPAIGNS . ' oxc ON oxb.campaignid = oxc.campaignid JOIN ' . TAB_CLIENTS . ' oxcl ON oxc.clientid = oxcl.clientid WHERE oxb.bannerid = ' . $adid);
$cache->save('campaign' . $adid, $campaign);
}
$win_notice = array(
'interval_start' => gmdate("Y-m-d H:00:00"),
'creative_id' => $adid,
'zone_id' =>	$exchange[0]['zoneid'],
'dj_win_bid' =>	(float)$campaign[0]['revenue']/1000,
'count' => 1,
'dj_dsp_share' => (float)$price/1000,
'dsp_request_id' => $bidid,
'adexchange' => $exchange_id,
'display_type' => $dtype
);
if($bidid != NULL) {
if(!isset($GLOBALS['db'])) $GLOBALS['db'] = new DB();
$GLOBALS['db']->query("INSERT INTO " . TAB_DSP_DATA_BKT_M . " (interval_start, creative_id, zone_id, dj_win_bid, count, dj_dsp_share, dsp_request_id,  adexchange, display_type) VALUES ('" . implode("','",$win_notice) . "') ON DUPLICATE KEY UPDATE dj_win_bid = '" . $win_notice['dj_win_bid'] . "', count=1, dj_dsp_share='" . $win_notice['dj_dsp_share'] . "', adexchange='" . $win_notice['adexchange'] . "', display_type='" . $dtype . "'");	
$clientid=$campaign[0]['clientid'];
$campid=$campaign[0]['campaignid'];
$winprice=(float)$price/1000;
$sql 	= "CALL update_budget('".$campid."','".$winprice."','".$clientid."');";
$GLOBALS['db']->query($sql);
} else {
error_log( $bidid . " Won notice else \n",3, 'php-error.log');
}
$GLOBALS['db']=null;
