<?php
define('DBDSN', 'mysql:dbname=adtechdb;host=192.168.100.106');
define('DBUSER', 'alef');
define('DBPASS', 'alef@543');
define('MONGOHOST', '192.168.100.104'); 
define('MONGONAME', 'adtechdb');
define('MONGOPORT', '27017');
define('MONGOUSER', 'alef');
define('MONGOPASS', 'alef@543'); 
define('TAB_THIRD_PARTY_EXCHANGE','djax_3rd_party_ad_exchange');
define('TAB_ZONES','ox_zones');
define('TAB_BANNERS','ox_banners');
define('TAB_CAMPAIGNS','ox_campaigns');
define('TAB_CLIENTS','ox_clients');
define('TAB_DSP_DATA_BKT_C','djax_dsp_data_bkt_c');
define('TAB_DSP_DATA_BKT_M','djax_dsp_data_bkt_m');
define('TAB_DSP_DATA_BKT_V','djax_dsp_data_bkt_v');
define('TAB_DSP_DATA_BKT_T','djax_dsp_data_bkt_track');
define('TAB_WIN_NOTES','djax_dsp_win_notice');
define('BASE_URL',((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']));
define('WIN_URL', BASE_URL . '/win_notice.php?exchange=EXCHANGE_ID&campid=CAMP_ID&clientid=CLIENT_ID&auctionId=${AUCTION_ID}&bidid=${AUCTION_BID_ID}&price=${AUCTION_PRICE}&impid=${AUCTION_IMP_ID}&seatid=${AUCTION_SEAT_ID}&adid=${AUCTION_AD_ID}&cur=${AUCTION_CURRENCY}');
define('CLICK_URL', BASE_URL . '/click.php?'); 
define('IMP_URL', BASE_URL . '/impression.php?');   
//define('IMAGE_PATH', 'https://ui.adcontentamtsolutions.net/adtech/ads/www/images/');
define('IMAGE_PATH', 'https://adelivery.adcontentamtsolutions.net/ads/www/images/');
define('TRACK_URL', BASE_URL . 'track.php?');
$opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_NUM,PDO::ATTR_PERSISTENT => TRUE];
$GLOBALS['dbh'] = new DB($opt);
try 
{

$cache = new Caching();
if(!$inputs = $cache->get('ex_'.$exchange_id)) {
$sql="select lower(exchange_name) from djax_3rd_party_ad_exchange where exchange_id='".$exchange_id."'";
foreach ($GLOBALS['dbh']->query($sql) as $key => $aAd) {
$exchanges[1] = $aAd[0];
$cache->save('ex_'.$exchange_id, $exchanges[1]);
}

}else
{
 $exchanges[1] =$inputs; 
}

}
catch (Exception $e) {
error_log(print_r($e->getMessage(),true) . "\n",3, 'php-error.log');
header("HTTP/1.0 204");exit;
}

//$exchanges = array(1 => 'test1', 2 => 'test2', 3 => 'test3', 4 => 'test4', 5 => 'test5');
class Caching {
protected $_memcached;
protected $_config = array('host' => '127.0.0.1', 'port' => 11211, 'weight' => 1);
public function __construct() {
if (class_exists('Memcached', FALSE)) {
$this->_memcached = new Memcached();
} elseif (class_exists('Memcache', FALSE)) {
$this->_memcached = new Memcache();
} else {
return;
}
if ($this->_memcached instanceof Memcache) {
$this->_memcached->addServer($this->_config['host'], $this->_config['port'], TRUE, $this->_config['weight']);
} elseif ($this->_memcached instanceof Memcached) {
$this->_memcached->addServer($this->_config['host'], $this->_config['port'], $this->_config['weight']);
}
}
public function get($id) {
$data = $this->_memcached->get($id);
return is_array($data) ? $data[0] : $data;
}
public function save($id, $data, $ttl = 60, $raw = FALSE) {
if ($raw !== TRUE) {
$data = array($data,
time(),
$ttl
);
}
if ($this->_memcached instanceof Memcached) {
return $this->_memcached->set($id, $data, $ttl);
} elseif ($this->_memcached instanceof Memcache) {
return $this->_memcached->set($id, $data, 0, $ttl);
}
return FALSE;
}
public function delete($id) {
return $this->_memcached->delete($id);
}
public function increment($id, $offset = 1) {
return $this->_memcached->increment($id, $offset);
}
public function decrement($id, $offset = 1) {
return $this->_memcached->decrement($id, $offset);
}
public function clean() {
return $this->_memcached->flush();
}
public function cache_info() {
return $this->_memcached->getStats();
}
public function get_metadata($id) {
$stored = $this->_memcached->get($id);
if (count($stored) !== 3) {
return FALSE;
}
list($data, $time, $ttl) = $stored;
return array(
'expire' => $time + $ttl,
'mtime' => $time,
'data' => $data
);
}
public function is_supported() {
return (extension_loaded('memcached') OR extension_loaded('memcache'));
}
public function __destruct() {
if ($this->_memcached instanceof Memcache) {
$this->_memcached->close();
} elseif ($this->_memcached instanceof Memcached && method_exists($this->_memcached, 'quit')) {
$this->_memcached->quit();
}
}
}
class DB
{
static private $PDOInstance;
public function __construct($driver_options = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,PDO::ATTR_PERSISTENT => TRUE))
{
if (!self::$PDOInstance) {
try {
self::$PDOInstance = new PDO(DBDSN, DBUSER, DBPASS, $driver_options);
}
catch (PDOException $e) {
error_log(print_r($e->getMessage(),true)."\n",3, 'php-error.log');
header("HTTP/1.0 204");exit;
}
}
return self::$PDOInstance;
}
public function beginTransaction()
{
return self::$PDOInstance->beginTransaction();
}
public function commit()
{
return self::$PDOInstance->commit();
}
public function errorCode()
{
return self::$PDOInstance->errorCode();
}
public function errorInfo()
{
return self::$PDOInstance->errorInfo();
}
public function exec($statement)
{
return self::$PDOInstance->exec($statement);
}
public function execute()
{
return self::$PDOInstance->execute();
}
public function getAttribute($attribute)
{
return self::$PDOInstance->getAttribute($attribute);
}
public function getAvailableDrivers()
{
return Self::$PDOInstance->getAvailableDrivers();
}
public function lastInsertId($name)
{
return self::$PDOInstance->lastInsertId($name);
}
public function prepare($statement, $driver_options = false)
{
if (!$driver_options)
$driver_options = array();
return self::$PDOInstance->prepare($statement, $driver_options);
}
public function query($statement)
{
return self::$PDOInstance->query($statement);
}
public function queryFetchAllAssoc($statement)
{
return self::$PDOInstance->query($statement)->fetchAll(PDO::FETCH_ASSOC);
}
public function queryFetchRowAssoc($statement)
{
return self::$PDOInstance->query($statement)->fetch(PDO::FETCH_ASSOC);
}
public function queryFetchColAssoc($statement)
{
return self::$PDOInstance->query($statement)->fetchColumn();
}
public function quote($input, $parameter_type = 0)
{
return self::$PDOInstance->quote($input, $parameter_type);
}
public function rollBack()
{
return self::$PDOInstance->rollBack();
}
public function setAttribute($attribute, $value)
{
return self::$PDOInstance->setAttribute($attribute, $value);
}
}
