<?php

error_reporting(E_ALL);
ini_set("log_errors", 1);
ini_set("error_log", "php-error.log");

$exchange_id = (isset($_GET['ex']) && is_numeric($_GET['ex'])) ? $_GET['ex'] : 0;
if($exchange_id == 0){header("HTTP/1.0 204");exit;}
require_once('config.php');
$adm = '';
try {
$opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_NUM,PDO::ATTR_PERSISTENT => TRUE];
$GLOBALS['dbh'] = new DB($opt);
$m = new MongoClient('mongodb://' . MONGOHOST, array('username' => MONGOUSER, 'password' => MONGOPASS, 'db'=> MONGONAME ));
$GLOBALS['mdb'] = $m->{MONGONAME};
if($_SERVER['REQUEST_METHOD'] === 'POST') {
 $req_arr = json_decode(file_get_contents( 'php://input' ),true) ;
} else {
function fileinput($folder='samples'){
$cache = new Caching();
if(!$inputs = $cache->get('inputs')) {
$files = scandir($folder); 
$input = array();
foreach($files as $file){
if(is_file($folder . '/' . $file)) $inputs[] = $folder . '/' . $file;
}
$cache->save('inputs', $inputs);
}
if($requests = file_get_contents($inputs[array_rand($inputs)])){
$array = json_decode((string)$requests, true);
$json = $array[rand(0, count($array) - 1)];
}
return $json;
}
$req_arr = fileinput();
}
if (!empty($req_arr)) {
$nobid = TRUE;
$request	= $req_arr;
$request['exchange_id'] = (int)$GLOBALS['exchange_id'];
$request['date_time'] = new MongoDate();
$request['interval_start'] = gmdate('Y-m-d H:i:s');
$request['geos'] = (isset($request['device']['geo']['country']) ? $request['device']['geo']['country'] : 'USA');
$result = dsp_adprocessing();  
//~ print_r($result);die("=d--=");
if($result != '') {
$host         = empty($result['2']) ? BASE_URL : parse_url($result['2'], PHP_URL_HOST);
$host         = preg_replace('/^(www\.)/i', '', $host);
$cat		  = isset($request['app']['cat'][0]) ? $request['app']['cat'][0] : (isset($request['site']['pagecat'][0])?$request['site']['pagecat'][0]:array());
if ($result['5'] == 'M_JS' || $result['5'] == 'M_IFRAME' || $result['5'] == 'M_IMG' || $result['5'] == 'W_IMG') { 
$nobid = FALSE;
$adm = "<a href=" . CLICK_URL . base64_encode("exchange=" . $GLOBALS['exchange_id'] . "&url=" . $result['17'] . "&bidid=" . $request['id'] . "&dtype=" . $request['extra']['dtype']."&adid=" . $result['6'] ) . "' target='_blank'><img src='" . IMAGE_PATH . $result['7'] . "' alt='" . $result['8'] . "' /></a><img src='".IMP_URL .base64_encode("exchange=" . $GLOBALS['exchange_id'] . "&bidid=".$request['id'] ."&dtype=" . $request['extra']['dtype']. "&adid=" . $result['6']) . "' alt='' width='0' height='0' />";
} 
else if($result['5']=='W_TEXT' || $result['5']=='M_TEXT')
{
$nobid = FALSE;
$adm = "<a href=" . CLICK_URL . base64_encode("exchange=" . $GLOBALS['exchange_id'] . "&url=" . $result['17'] . "&bidid=" . $request['id'] . "&dtype=" . $request['extra']['dtype']."&adid=" . $result['6'] ) . "' target='_blank'> ".$result['8']."</a><img src='".IMP_URL .base64_encode("exchange=" . $GLOBALS['exchange_id'] . "&bidid=".$request['id'] ."&dtype=" . $request['extra']['dtype']. "&adid=" . $result['6']) . "' alt='' width='0' height='0' />";
}
else if(isset($request['imp'][0]['video'])) {

$nobid = FALSE;
$request['extra']['result']=$result;
$adm=generateVastTag();
}	
else {
$adm = '';
}	 
$request['response'] = array(
'id' => $request['id'],
'seatbid' => array(
array(
'bid' => array(
array(
'id' => md5(uniqid(mt_rand())),
'impid' => $request['imp'][0]['id'],
'price' => $result['1'],
'adid' => $result['6'],
'nurl' => BASE_URL . 'win_notice.php?exchange=' . $GLOBALS['exchange_id'] . '&dtype='.$request['extra']['dtype'].'&auctionId=${AUCTION_ID}&bidid=${AUCTION_BID_ID}&price=${AUCTION_PRICE}&impid=${AUCTION_IMP_ID}&seatid=${AUCTION_SEAT_ID}&adid=${AUCTION_AD_ID}&cur=${AUCTION_CURRENCY}',
'adm' => $adm,
'adomain' => array(
$host
),
'iurl' => IMAGE_PATH.$result['7'],
'cid' => $result['0'],
'crid' => $result['6'],
'attr' => array(),
'ext' => null,
'cat' => is_array($cat)?$cat:array($cat)
)
),
'seat' => '0',
'group' => '0'
)
),
'bidid' => $request['id'],
'customdata' => null,
'cur' => 'USD',
'ext' => null
);
} 
unset($request['extra']);
$res_stat=(isset($request['response']))?1:0;
$reqs['geos'] = $request['geos'];
$reqs['date_time'] = new MongoDate();
$reqs['devicetype'] = $request['device']['devicetype'];
$reqs['id'] = $request['id'];
$reqs['exchange_id'] = $request['exchange_id'];
$reqs['interval_start'] = $request['interval_start'];
$reqs['response'] = $res_stat;
if($nobid == TRUE) unset($request['response']);
$GLOBALS['mdb']->{$exchanges[1] . "_" . gmdate('dmyH')}->insert($reqs);
if (isset($_GET['testbid']) && $_GET['testbid'] == "nobid") {
header("HTTP/1.0 204");exit;
}
if (isset($request['response']) && ($nobid == FALSE) && (isset($result['1']) &&  $result['1'] != '0')) { 
$response = json_encode($request['response']);
header('Content-Type: application/json');
print_r($response);
} else {
header("HTTP/1.0 204");exit;
}
} 
} catch (MongoConnectionException $e) {
error_log(print_r($e->getMessage(),true) . "\n",3, 'php-error.log');
header("HTTP/1.0 204");exit;
} catch (Exception $e) {
error_log(print_r($e->getMessage(),true) . "\n",3, 'php-error.log');
header("HTTP/1.0 204");exit;
}
function dsp_adprocessing(){
global $request;
$deviceType = array('0'=>'ALL','1'=>'MOBILE','2'=>'WEB','3'=>'TV','4'=>'MOBILE','5'=>'MOBILE','6'=>'DEVICE','7'=>'STB');
$request['extra']['dtype'] = (isset($request['device']['devicetype']) ? $request['device']['devicetype'] : 0);

$request['extra']['devicetype'] = $deviceType[$request['extra']['dtype']];

$connectionType = array('0','1','2','3','4','5','6');
$bannerAdTypes = array('1','2','3','4');
$creativeAttr = array('0','1','2','3','4','5','6');
$djax_allads      = djax_getAd(); 
$results = '';

if (!empty($djax_allads)) {
$filtered	= applyFilter($djax_allads);
$results 	= priorityFilter($filtered);
}

//~ print_r($results);die("--DSPPROCESS");

return $results;
}
function djax_getAd(){
global $request;
$aRows	=	[];
if(isset($request['imp'][0]['banner']))
{
$bid_floor      = empty($request['imp'][0]['bidfloor']) ? 0 : $request['imp'][0]['bidfloor'];
$width          = isset($request['imp'][0]['banner']['w']) ? $request['imp'][0]['banner']['w'] : 0;
$height         = isset($request['imp'][0]['banner']['h']) ? $request['imp'][0]['banner']['h'] : 0;
$txt_bannertype = empty($request['imp'][0]['banner']['mimes']) ? '' : $request['imp'][0]['banner']['mimes'];
$badv           = empty($request['badv']) ? 'test.com' : implode('|', $request['badv']);
$bcat           = empty($request['bcat']) ? 'test' : implode('|', $request['bcat']);
$btype          = empty($request['imp'][0]['banner']['btype']) ? '' : $request['imp'][0]['banner']['btype'];
$all_type		= ["text/javascript","application/javascript","image/jpeg","image/png","image/gif",'text/plain','text/html'];
$bannertype     = array(1 => '"M_TEXT"',2 => '"M_IMG"',3 => '"M_JS"',4 => '"M_IFRAME"');
$alltype		= [1,2,3,4];
if (!empty($txt_bannertype)) {
	//~ die("IF");
if (in_array('application/javascript', $txt_bannertype) || in_array('text/javascript', $txt_bannertype)) {
$request['extra']['storageType'] = "html";
} elseif (in_array('image/gif', $txt_bannertype) || in_array('image/jpeg', $txt_bannertype) || in_array('image/png', $txt_bannertype)) {
$request['extra']['storageType'] = "web";
} elseif (in_array('text/plain', $txt_bannertype) || in_array('text/html', $txt_bannertype)) {
$width       = 0;
$height      = 0;
$request['extra']['storageType'] = "txt";
} else {
$request['extra']['storageType'] = "javascript";
}

} else
{
	//~ die("ELSE");
$request['extra']['storageType'] = "web";
$allowed_type   = array_diff($alltype, (array)$btype);
$allowed_type   = array_intersect_key($bannertype, array_flip($allowed_type));
$request['extra']['targetType'] = implode(',', $allowed_type);
$request['extra']['devicetype']=(($request['imp'][0]['banner']['w'] <= 0 && $request['imp'][0]['banner']['h'] <= 0) && $request['extra']['storageType'] = "txt")?'WEB':$request['extra']['devicetype'];
$siteappcat		  = preg_replace("([-]+[0-9]{1,2})", "",isset($request['app']['cat']) ? $request['app']['cat'] : (isset($request['site']['cat'])?$request['site']['cat']: array()));
$siteappsectioncat  = preg_replace("([-]+[0-9]{1,2})", "",isset($request['app']['sectioncat']) ? $request['app']['sectioncat'] : (isset($request['site']['sectioncat'])?$request['site']['sectioncat']: array()));
$siteapppagecat =	preg_replace("([-]+[0-9]{1,2})", "",isset($request['app']['pagecat']) ? $request['app']['pagecat'] : (isset($request['site']['pagecat'])?$request['site']['pagecat']: array()));
$publishercat		  = preg_replace("([-]+[0-9]{1,2})", "",isset($request['app']['publisher']['cat']) ? $request['app']['publisher']['cat'] : (isset($request['site']['publisher']['cat'])?$request['site']['publisher']['cat']: array()));
$finalcat = array_unique(array_merge($siteappcat, $siteappsectioncat, $siteapppagecat, $publishercat));
$cat=is_array($finalcat)?implode(',',$finalcat):'';

}

 //~ $sql            = "call get_banners_cat ('" . $width . "','" . $height . "','" . $bid_floor . "','" . $request['extra']['devicetype'] . "','" . $request['extra']['storageType'] . "', " . $GLOBALS['exchange_id'] . ",'" . $cat . "')";
 $sql            = "call get_banners_cat ('" . $width . "','" . $height . "','" . $bid_floor . "','".$request['extra']['devicetype']."','" . $request['extra']['storageType'] . "', " . $GLOBALS['exchange_id'] . ",'" . $cat . "')";
 
//~ echo $sql;die;
foreach ($GLOBALS['dbh']->query($sql) as $key => $aAd) {
$aRows[] = $aAd;
}
//~ print_r($aRows);die("==");
}
else if(isset($request['imp'][0]['video']))
{
$bid_floor      = empty($request['imp'][0]['bidfloor']) ? 0 : $request['imp'][0]['bidfloor'];
$badv           = empty($request['badv']) ? 'test.com' : implode('|', $request['badv']);
$bcat           = empty($request['bcat']) ? 'test' : implode('|', $request['bcat']);
$mimes_type 	= empty($request['imp'][0]['video']['mimes']) ? '' : implode(',',$request['imp'][0]['video']['mimes']);

// $mime			=str_replace('video/','',$mimes_type);
$mime='video/x-mp4,mp4,flv';
$prefix 		= 'V_';
$linearity		= empty($request['imp'][0]['video']['linearity']) ? 0 : $request['imp'][0]['video']['linearity'];

if($request['imp'][0]['video']['linearity']==1){
$linearity = $prefix.'IN';
}else if($request['imp'][0]['video']['linearity']==2){
$linearity = $prefix.'OL';
}else{
$linearity = $prefix.'IN,'.$prefix.'OL';
}
if(isset($request['imp'][0]['video']['delivery'][0]) &&  $request['imp'][0]['video']['delivery'][0]==1) 
{ 
$delivery = 'streaming';
} 
else if(isset($request['imp'][0]['video']['delivery'][0]) &&  $request['imp'][0]['video']['delivery'][0]==2) 
{ 
$delivery = 'progressive';
} 
else {
$delivery = 'streaming,progressive';
}
$delivery = 'streaming,progressive';
$protocols=array(2);
if($request['imp'][0]['video']['linearity']==1)
{ 
$sql            = "call getvideoads('" . $mime . "','" . $bid_floor . "','" . $linearity . "','" . $delivery . "'," . $GLOBALS['exchange_id'] . ")"; 
$aRows	=	[];   
foreach ($GLOBALS['dbh']->query($sql) as $key => $aAd) {
$aRows[] = $aAd;
}
}
if($request['imp'][0]['video']['linearity']==2) //Overlay
{
$sql            = "call getwrapper('" . $bid_floor . "','" . $linearity . "'," . $GLOBALS['exchange_id'] . ")"; 
 foreach ($GLOBALS['dbh']->query($sql) as $key => $aAd) {
 $aRows[] = $aAd;
 }
}
}
//~ print_r($aRows);exit;

return $aRows;
}
function applyFilter($ads) {
global $request;
if (isset($request['site']) && count($request['site']) > 0) {
$request['extra']['target'] = 'site';
} else if (isset($request['app']) && count($request['app']) > 0) {
$request['extra']['target'] = 'app';
} else {
$request['extra']['target'] = '';
}
if ($request['extra']['target'] != ''){
$cat = isset($request[$request['extra']['target']]['cat']) ? $request[$request['extra']['target']]['cat'] : array();
$sectioncat = isset($request[$request['extra']['target']]['sectioncat']) ? $request[$request['extra']['target']]['sectioncat'] : array();
$pagecat = isset($request[$request['extra']['target']]['pagecat']) ? $request[$request['extra']['target']]['pagecat'] : array();
$finalCat = array_unique(array_merge($cat, $sectioncat, $pagecat));
$request['extra']['allowCat'] = array_unique(array_map("mainCategory", $finalCat));
} else {
$request['extra']['allowCat'] = array();
}
$request['extra']['blockedCat'] = isset($request['bcat']) ? $request['bcat'] : '';
foreach ($ads as $key => $value) {
if(!empty($value['10']) && !empty($allowCat)) {
if(!in_array($value['10'], $allowCat)) {
unset($ads[$key]);continue;
}	
}
if(!empty($value['10']) && !empty($blockedCat)) {
if(in_array($value['10'], $blockedCat)) {
unset($ads[$key]);continue;
}	
}
$limitString = str_replace(':', '_',str_replace('MAX_','',$value['3']));
$limitArray = explode(' and ', $limitString);
if($limitArray[0] != '' && $limitArray[0] != '0') {
@eval('$result = (' . $limitString . ');');
if($result === FALSE) {
unset($ads[$key]);continue;
}
}
}
return $ads;
}
function priorityFilter($ads) {
return (count($ads) > 0) ? $ads[rand(0,(count($ads)-1))] : '';
}
function checkTime_Hour($limitation, $operator)
{
return true;
}
function mainCategory($cat){
return explode('-', $cat) [0];
}
function handset($limitation, $operator){
return TRUE;
}
function device_type($limitation, $operator){
return TRUE;
}
function supplytype($limitation, $operator){
return true;
}
function os($limitation, $operator) {
$os = strtolower($GLOBALS['device']['os']);
if (empty($limitation) && empty($os)) {
return true;
} else if (empty($limitation) && !empty($os)) {
return true;
} else if (!empty($os)) {
preg_match("(" . str_replace(',', '|', strtolower(str_replace(' ', '', $limitation))) . ")", $os, $matches);
if (!empty($matches)) {
return TRUE;
} else {
return FALSE;
}
} else {
return TRUE;
}
}
function mobile_geo_ip($limitation, $operator){
$ip = empty($GLOBALS['device']['ip']) ? '' : $GLOBALS['device']['ip'];
if (empty($ip)) {
$ip = empty($GLOBALS['user']['geo']['ip']) ? '' : $GLOBALS['user']['geo']['ip'];
}
if (empty($ip) && empty($limitation)) {
return true;
} else if (!empty($ip) && empty($limitation)) {
return true;
} else if (!empty($ip)) {
$target_ips = explode(',', $limitation);
foreach ($target_ips as $target_ip) {
$ip_range = explode("-", $target_ip);
if (ip2long($ip_range[0]) <= ip2long($ip) && ip2long($ip_range[1]) >= ip2long($ip)) {
return TRUE;
}
}
return FALSE;
} else {
return TRUE;
}
}
function mobile_geo_isp($limitation, $operator){
$limit 		= explode(',',strtolower($limitation));
$carrier 	= empty($GLOBALS['device']['carrier'])?"":strtolower($GLOBALS['device']['carrier']);
if(!empty($carrier)){if(in_array($carrier, $limit)){return TRUE;}else{return FALSE;}}
else{return TRUE;}
}
function mob_os_version($limitation, $operator){
$os = strtolower($GLOBALS['device']['osv']);
if (empty($limitation) && empty($os)) {
return true;
} else if (empty($limitation) && !empty($os)) {
return true;
} else if (!empty($os)) {
preg_match("(" . str_replace(',', '|', strtolower(str_replace(' ', '', $limitation))) . ")", $os, $matches);
if (!empty($matches)) {
return TRUE;
} else {
return FALSE;
}
} else {
return TRUE;
}
}
function connectiontype($limitation, $operator){
$connectiontype = strtolower($GLOBALS['device']['connectiontype']);
if (empty($limitation) && empty($connectiontype)) {
return true;
} else if (empty($limitation) && !empty($connectiontype)) {
return true;
} else if (!empty($connectiontype)) {
$connectiontype = strtolower(str_replace(' ', '', $connectiontype));
$available			=	[0,1,2,3,4,5,6];
if ($connectiontype == 2) {
$connect = 'wifi';
} else if ($connectiontype == 4 || $connectiontype == 5 || $connectiontype == 6) {
$connect = 'gprs';
} else {
$connect = 'others';
}
if (!empty($connect)) {
preg_match("(" . str_replace(',', '|', strtolower(str_replace(' ', '', $limitation))) . ")", $connect, $matches);
if (!empty($matches)) {
return TRUE;
} else {
return FALSE;
}
} else {
return TRUE;
}
} else {
return TRUE;
}
}
function country($limitation, $operator) {
return checkGeo_Country($limitation, $operator);
}
function checkGeo_Country($limitation, $operator) {
global $request;
$country = '';
if (isset($request['device']['geo'])){
$country = isset($request['device']['geo']['country']) ? $request['device']['geo']['country'] : '';
}
if ($country == '' && isset($request['user']['geo'])){
$country = isset($request['user']['geo']['country']) ? $request['device']['geo']['country'] : '';
}
try
{
if(!$inputs = $GLOBALS['cache']->get('country_'.$country)) {
$sql = "call get_geo('" . $country. "')"; 
foreach ($GLOBALS['dbh']->query($sql) as $key => $geo) {
$country = $geo[0];
$GLOBALS['cache']->save('country_'.$country, $country);
}
}else
{
 $country =$inputs; 
}
}
catch (Exception $e) {
error_log(print_r($e->getMessage(),true) . "\n",3, 'php-error.log');
header("HTTP/1.0 204");exit;
}

if (!empty($country)){
preg_match("(" . str_replace(',', '|', $limitation) . ")", $country, $matches);
return (!empty($matches)) ? TRUE : FALSE;
}
return TRUE;
}
function profile_keyword($limitation, $operator) {
global $request;
$keywords = array();
if (isset($request[$request['extra']['target']])){
$site_key = isset($request[$request['extra']['target']]['keywords']) ? $request[$request['extra']['target']]['keywords'] : '';
if(strlen($site_key) > 1)
$keywords = array_merge($keywords, explode(",", $site_key));
}
if (isset($request['user'])){
$user_key = isset($request['user']['keywords']) ? $request['user']['keywords'] : '';
if(strlen($user_key) > 1)
$keywords = array_merge($keywords, explode(",", $user_key));
}
$limitations = explode(',', $limitation);
if(sizeof($limitations) == 0) return TRUE;
if(sizeof($keywords) == 0) return TRUE;
$common = array_uintersect(array_map('trim', $keywords), array_map('trim', $limitations), "strcasecmp");
if(sizeof($common) == 0) return FALSE;
return TRUE;
}
function generateVastTag(){ 
global $request;
if($request['extra']['result'][22]!=0 && isset($request['imp'][0]['video']['companionad'])){
$width			   =(isset($request['imp'][0]['video']['companionad']['w']) ? $request['imp'][0]['video']['companionad']['w'] : 0);
$height			   =(isset($request['imp'][0]['video']['companionad']['h']) ? $request['imp'][0]['video']['companionad']['h'] : 0);
$companion_bannerid=$request['extra']['result'][22];
if(!isset($GLOBALS['dbh'])) $GLOBALS['dbh'] = new DB();
$sql               = "call getcompanion('" . $width . "','" . $height . "','" . $companion_bannerid . "')"; 
foreach ($GLOBALS['dbh']->query($sql) as $key => $aAd) {
$companion_ad = $aAd;
}
}
else{$companion_ad='';}
$protocols=isset($request['imp'][0]['video']['protocols']);
$ver =2;
if($ver > 3){$version = $ver - 3;}else{$version = $ver;}
$video_type     = array('video/x-mp4','mp4');
$vast_video_type='';
if(in_array($request['extra']['result'][20],$video_type )){
$vast_video_type='video/mp4';}
else{$vast_video_type='video/mp4';}
$request['extra']['vast_video_type']=$vast_video_type;
$request['extra']['companion_ad']=$companion_ad;
header('Access-Control-Allow-Origin:*');
$player	   ='';
$player	  .= '<VAST version="'.$version.'.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="vast.xsd">';
$player   .= '<Ad id="'.$request['extra']['result'][6].'">';
if(in_array($request['extra']['result'][21],array('streaming','progressive')))
{
$player	  .= '<InLine>';
$player	  .= '<AdSystem>VAST Inline_Ad</AdSystem>';
$player	  .= '<AdTitle><![CDATA['.$request['extra']['result'][8].']]></AdTitle>';
$player	  .= '<Impression><![CDATA['.IMP_URL.'exchange='.$GLOBALS['exchange_id'].'&bidid='.$request['id'].'&dtype='.$request['extra']['dtype'].'&adid='.$request['extra']['result'][6].']]></Impression>';
$player	  .= '<Creatives>';
$player	  .= '<Creative>';
if($request['imp'][0]['video']['linearity']==1)
{
$player	  .= linear_ad();
}
$player	  .= '</Creative>';
$player	  .= companion();
$player	  .= '</Creatives>';
$player	  .= '</InLine>';
}
else if(in_array($request['extra']['result']['29'],array('image_overlay')))
{
$player	  .= '<InLine>';
$player	  .= '<AdSystem>VAST Overlay</AdSystem>';
$player	  .= '<AdTitle><![CDATA['.$request['extra']['result'][8].']]></AdTitle>';
$player	  .= '<Impression><![CDATA['.IMP_URL.'exchange='.$GLOBALS['exchange_id'].'&bidid='.$request['id'].'&dtype='.$request['extra']['dtype'].'&adid='.$request['extra']['result'][6].']]></Impression>';
$player	  .= '<Creatives>';
$player	  .= '<Creative>';
if($request['imp'][0]['video']['linearity']==2)
{
$player	  .= nonlinear_ad();
}
$player	  .= '</Creative>';
$player	  .= companion();
$player	  .= '</Creatives>';
$player	  .= '</InLine>';
}
else if(in_array($request['extra']['result'][21 ],array('vast')))
{ 
$adurl=$request['extra']['result'][30];
$player	  .= '<Wrapper>';
$player	  .= '<AdSystem>VAST Wrapper_Ad</AdSystem>';
$player	  .= '<AdTitle><![CDATA['.$request['extra']['result'][8].']]></AdTitle>';
$player	  .= '<VASTAdTagURI><![CDATA['.$adurl.']]></VASTAdTagURI>';
$player	  .= '<Impression><![CDATA['.IMP_URL.'exchange='.$GLOBALS['exchange_id'].'&bidid='.$request['id'].'&dtype='.$request['extra']['dtype'].'&adid='.$request['extra']['result'][6].']]></Impression>';
$player	  .= '<Creatives>';
if($request['imp'][0]['video']['linearity']==1)
{
$player	  .= '<Creative>';
$player	  .= linear_ad();
$player	  .= '</Creative>';
}
else if($request['imp'][0]['video']['linearity']=2)
{
$player	  .= '<Creative>';
$player	  .= nonlinear_ad();
$player	  .= '</Creative>';
}
$player	  .= companion();
$player	  .= '</Creatives>';
$player	  .= '</Wrapper>';
}
$player	  .= '</Ad>';
$player	  .= '</VAST>';
return  $player;
}
function linear_ad()
{
global $request;
$player	   ='';
if(in_array($request['extra']['result'][21 ],array('streaming','progressive')))
{
$player	  .= '<Linear>';
$player	  .= '<Duration>00:00:'.$request['extra']['result'][23].'</Duration>';
$player	  .= linear_track_event();
$player	  .= '<VideoClicks>';
$player	  .= '<ClickThrough><![CDATA['.CLICK_URL.base64_encode("exchange=".$GLOBALS['exchange_id']."&bidid=".$request['id']."&url=".$request['extra']['result'][9]."&dtype=".$request['extra']['dtype']."&adid=".$request['extra']['result'][6]."").']]></ClickThrough>';
$player	  .= '</VideoClicks>';
$player	  .= '<MediaFiles>';
$player	  .= '<MediaFile delivery="'.$request['extra']['result'][21].'" type="'.$request['extra']['vast_video_type'].'" bitrate="'.$request['extra']['result'][24].'" width="'.$request['imp'][0]['video']['w'].'" height="'.$request['imp'][0]['video']['h'].'" scalable="true" maintainAspectRatio="true"> <![CDATA['. IMAGE_PATH .$request['extra']['result'][7].']]></MediaFile>';
$player	  .= '</MediaFiles>';
$player	  .= '</Linear>';
}
else if(in_array($request['extra']['result'][21 ],array('vast')))
{
$player	  .= '<Linear>';
$player	  .= linear_track_event();
$player	  .= '</Linear>';
}
return $player;
}
function nonlinear_ad()
{
global $request;
$player	   ='';
$player	  .= '<NonLinearAds>';
$player	  .= nonlinear_track_event();
$player	  .= '<NonLinear  id="overlay" width="'.$request['extra']['result']['31'].'" height="'.$request['extra']['result']['30'].'" maintainAspectRatio="true"  scalable="true">';
$player	  .= '<StaticResource creativeType="image/png">';
$player	  .= '<![CDATA['. IMAGE_PATH .$request['extra']['result'][7].']]>';
$player	  .= '</StaticResource>';
$player	  .= '<NonLinearClickThrough>';
$player	  .= '<![CDATA['.CLICK_URL.base64_encode("exchange=".$GLOBALS['exchange_id']."&bidid=".$request['id']."&url=".$request['extra']['result'][9]."&dtype=".$request['extra']['dtype']."&adid=".$request['extra']['result'][6]."").']]>';
$player	  .= '</NonLinearClickThrough>';
$player	  .= '</NonLinear>';
$player	  .= '</NonLinearAds>';
return $player;

}
function linear_track_event()
{
global $request;
$player	   ='';
$events = array('start','firstquartile','midpoint','thirdquartile','complete','pause','mute','fullscreen','unmute','creativeView','acceptInvitation','rewind','resume');
$player	  = '<TrackingEvents>';
foreach($events as $event){
$player	  .='<Tracking event="'.$event.'"><![CDATA['.TRACK_URL.'exchange='.$GLOBALS['exchange_id'].'&bidid='.$request['id'].'&dtype='.$request['extra']['dtype'].'&adid='.$request['extra']['result'][6].'&event='.$event.']]></Tracking>';
}
$player	  .= '</TrackingEvents>';
return $player;	
}
function companion()
{
global $request;
$player	   ='';
if($request['extra']['companion_ad']!='')
{
$player	  .= '<Creative>';
$player	  .= '<CompanionAds>';
$player	  .= '<Companion id="1" width="'.$request['extra']['companion_ad'][2].'" height="'.$request['extra']['companion_ad'][3].'" resourceType="HTML"><StaticResource><![CDATA['. IMAGE_PATH .$request['extra']['companion_ad'][0].']]></StaticResource><CompanionClickThrough><![CDATA['.CLICK_URL.base64_encode("exchange=".$GLOBALS['exchange_id']."&bidid=".$request['id']."&url=".$request['extra']['companion_ad'][4]."&dtype=".$request['extra']['dtype']."&adid=".$request['extra']['companion_ad'][1]."").']]></CompanionClickThrough></Companion>';
$player	  .= '</CompanionAds>';
$player	  .= '</Creative>';
}
else
{
$player	  .= '';
}
return $player;	
}
function nonlinear_track_event()
{
global $request;
$player	   ='';
$events = array('creativeView','expand','collapse','acceptInvitation','close','fullscreen');
$player	  = '<TrackingEvents>';
foreach($events as $event){
$player	  .='<Tracking event="'.$event.'"><![CDATA['.TRACK_URL.'exchange='.$GLOBALS['exchange_id'].'&bidid='.$request['id'].'&dtype='.$request['extra']['dtype'].'&adid='.$request['extra']['result'][6].'&event='.$event.']]></Tracking>';
}
$player	  .= '</TrackingEvents>';
return $player;		
}
function djax_macro_replace($adurl)
{
global $request;
$width          = isset($request['imp'][0]['video']['w']) ? $request['imp'][0]['video']['w'] : 0;
$height         = isset($request['imp'][0]['video']['h']) ? $request['imp'][0]['video']['h'] : 0;
$geo_lat        = isset($request['device']['geo']['lat']) ? $request['device']['geo']['lat'] : '[GEO_LAT]';
$geo_lon        = isset($request['device']['geo']['lon']) ? $request['device']['geo']['lon'] : '[GEO_LON]';
$geo_region     = isset($request['device']['geo']['region']) ? $request['device']['geo']['region'] : '[REGION]';
$geo_city       = isset($request['device']['geo']['city']) ? $request['device']['geo']['city'] : '[CITY]';
$idfa     		= isset($request['ext']['udi']['gaid']) ? $request['ext']['udi']['gaid'] : '[IDFA]';
$device_carrier = empty($request['device']['carrier']) ? '' : $request['device']['carrier'];
$device_carrier = empty($device_carrier) ? $request['ext']['carriername'] : $device_carrier;
$adurl 			= str_replace('[TIMESTAMP]', 	time(), $adurl);
$adurl 			= str_replace('[CACHEBUSTING]', $request['id'], $adurl);
$adurl 			= str_replace('[CACHE_BREAKER]', $request['id'], $adurl);
$adurl 			= str_replace('[USERAGENT]', $request['device']['ua'], $adurl);
$adurl 			= str_replace('[DEVICEOS]', $request['device']['os'], $adurl);
$adurl 			= str_replace('[DEVICEOSV]', $request['device']['osv'], $adurl);
$adurl 			= str_replace('[DEVICEMAKE]', $request['device']['make'], $adurl);
$adurl 			= str_replace('[DEVICEMODEL]', $request['device']['model'], $adurl);
$adurl 			= str_replace('[CARRIER]', $device_carrier, $adurl);
$adurl 			= str_replace('[IPADDRESS]', $request['device']['ip'], $adurl);
$adurl 			= str_replace('[GEO_LAT]',$geo_lat, $adurl);
$adurl 			= str_replace('[GEO_LON]',$geo_lon, $adurl);
$adurl 			= str_replace('[COUNTRY]',$request['device']['geo']['country'], $adurl);
$adurl 			= str_replace('[REGION]',$geo_region, $adurl);
$adurl 			= str_replace('[CITY]',$geo_city, $adurl);
$adurl 			= str_replace('[WIDTH]',$width , $adurl);
$adurl 			= str_replace('[HEIGHT]',$height, $adurl);
$adurl 			= str_replace('[IDFA]',$idfa, $adurl);
if(isset($request['site']))
{
$adurl 			= str_replace('[DOMAIN]',$request['site']['domain'], $adurl);
$adurl 			= str_replace('[SITE]',$request['site']['name'], $adurl);
$publisher		= empty($request['site']['publisher']['id']) ? '' : $request['site']['publisher']['id'];
$publisher      = empty($publisher) ? $request['site']['publisher']['name'] : $publisher;
$adurl 			= str_replace('[PUBLISHER]',$publisher, $adurl);
}
else if(isset($request['app']))
{
$adurl 			= str_replace('[DOMAIN]',$request['app']['domain'], $adurl);
$adurl 			= str_replace('[SITE]',$request['app']['name'], $adurl);
$adurl 			= str_replace('[BUNDLEID]',$request['app']['bundle'], $adurl);
$adurl 			= str_replace('[APPSTOREURL]',$request['app']['storeurl'], $adurl);
$adurl 			= str_replace('[APPNAME]',$request['app']['name'], $adurl);
$adurl 			= str_replace('[SITE]',$request['app']['name'], $adurl);
$publisher		= empty($request['app']['publisher']['id']) ? '' : $request['app']['publisher']['id'];
$publisher      = empty($publisher) ? $request['app']['publisher']['name'] : $publisher;
$adurl 			= str_replace('[PUBLISHER]',$publisher , $adurl);
}
return $adurl;
}


