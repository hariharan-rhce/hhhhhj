<?php
error_reporting(E_ALL);
ini_set("log_errors", 1);
ini_set("error_log", "php-error.log");
parse_str(base64_decode($_SERVER["QUERY_STRING"]), $query_string);
$exchange_id = (isset($query_string['exchange']) && is_numeric($query_string['exchange'])) ? $query_string['exchange'] : 3;
require_once('config.php');
$adid = (isset($query_string['adid']) && is_numeric($query_string['adid'])) ? $query_string['adid'] : 0;
$bidid = (isset($query_string['bidid'])) ? $query_string['bidid'] : NULL;
$dtype = (isset($query_string['dtype']) && is_numeric($query_string['dtype'])) ? $query_string['dtype'] : 0;
$cache = new Caching();
if(!$exchange = $cache->get('exchange' . $exchange_id)) {
$GLOBALS['db'] = new DB(); 
$exchange = $GLOBALS['db']->queryFetchAllAssoc('SELECT ex.exchange_id, ex.rtb_version, ex.rtb_mode, oxz.zoneid FROM ' . TAB_THIRD_PARTY_EXCHANGE . ' ex JOIN ' . TAB_ZONES . ' oxz ON ex.exchange_id = oxz.dj_is_dsp WHERE ex.status = 1 AND ex.exchange_id = ' . $exchange_id);
$cache->save('exchange' . $exchange_id, $exchange);
}
$win_notice = array(
'interval_start' => gmdate("Y-m-d H:00:00"),
'creative_id' => $adid,
'zone_id' =>	$exchange[0]['zoneid'],
'dj_win_bid' =>	0,
'count' => 1,
'dsp_request_id' => $bidid,
'adexchange' => $exchange_id,
'display_type' => $dtype
);
// print_r($win_notice);exit;
if($bidid != NULL) {
if(!isset($GLOBALS['db'])) $GLOBALS['db'] = new DB();
$GLOBALS['db']->query("INSERT INTO " . TAB_DSP_DATA_BKT_C . " (interval_start, creative_id, zone_id, dj_win_bid, count, dsp_request_id, adexchange,display_type) VALUES ('" . implode("','",$win_notice) . "') ON DUPLICATE KEY UPDATE count=count+1");	
}
$GLOBALS['db']=null;
function redirect($url){
if (!preg_match('/^(?:javascript|data):/i', $url)) {
header('Location: '.$url);
sendStatusCode(302);
}
}
function sendStatusCode($iStatusCode) {
$arr = array(
100 => 'Continue',
101 => 'Switching Protocols',
200 => 'OK',
201 => 'Created',
202 => 'Accepted',
203 => 'Non-Authoritative Information',
204 => 'No Content',
205 => 'Reset Content',
206 => 'Partial Content',
300 => 'Multiple Choices',
301 => 'Moved Permanently',
302 => 'Found',
303 => 'See Other',
304 => 'Not Modified',
305 => 'Use Proxy',
306 => '[Unused]',
307 => 'Temporary Redirect',
400 => 'Bad Request',
401 => 'Unauthorized',
402 => 'Payment Required',
403 => 'Forbidden',
404 => 'Not Found',
405 => 'Method Not Allowed',
406 => 'Not Acceptable',
407 => 'Proxy Authentication Required',
408 => 'Request Timeout',
409 => 'Conflict',
410 => 'Gone',
411 => 'Length Required',
412 => 'Precondition Failed',
413 => 'Request Entity Too Large',
414 => 'Request-URI Too Long',
415 => 'Unsupported Media Type',
416 => 'Requested Range Not Satisfiable',
417 => 'Expectation Failed',
500 => 'Internal Server Error',
501 => 'Not Implemented',
502 => 'Bad Gateway',
503 => 'Service Unavailable',
504 => 'Gateway Timeout',
505 => 'HTTP Version Not Supported'
);
if (isset($arr[$iStatusCode])) {
$text = $iStatusCode . ' ' . $arr[$iStatusCode];
header($_SERVER["SERVER_PROTOCOL"] .' ' . $text);
}
}
redirect($query_string['url']);
