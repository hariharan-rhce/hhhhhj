<?php

// Show all information, defaults to INFO_ALL
phpinfo();

?>
