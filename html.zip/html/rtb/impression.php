<?php
//error_reporting(E_ALL);
ini_set("log_errors", 1);
ini_set("error_log", "php-error.log");

parse_str(base64_decode($_SERVER["QUERY_STRING"]), $query_string);
$exchange_id = (isset($query_string['exchange']) && is_numeric($query_string['exchange'])) ? $query_string['exchange'] : 3;
require_once('config.php');
$bidid = (isset($query_string['bidid'])) ? $query_string['bidid'] : NULL;
$adid = (isset($query_string['adid']) && is_numeric($query_string['adid'])) ? $query_string['adid'] : 0;
$dtype = (isset($query_string['dtype']) && is_numeric($query_string['dtype'])) ? $query_string['dtype'] : 0;
$cache = new Caching();
if(!$exchange = $cache->get('exchange' . $exchange_id)) {
$GLOBALS['db'] = new DB(); 

$exchange = $GLOBALS['db']->queryFetchAllAssoc('SELECT ex.exchange_id, ex.rtb_version, ex.rtb_mode, oxz.zoneid FROM ' . TAB_THIRD_PARTY_EXCHANGE . ' ex JOIN ' . TAB_ZONES . ' oxz ON ex.exchange_id = oxz.dj_is_dsp WHERE ex.status = 1 AND ex.exchange_id = ' . $exchange_id);
$cache->save('exchange' . $exchange_id, $exchange);
}
if($bidid != NULL && $exchange_id !=0 && $adid != 0) {
if(!isset($GLOBALS['db'])) $GLOBALS['db'] = new DB();
$impression = array(
'interval_start' => gmdate("Y-m-d H:00:00"),
'creative_id' => $adid,
'zone_id' =>	$exchange[0]['zoneid'],
'dj_win_bid' =>	0,
'count' => 1,
'dj_dsp_share' => 0,
'dsp_request_id' => $bidid,
'adexchange' => $exchange_id,
'impression' => 1,
'display_type' => $dtype
);




$GLOBALS['db']->query("INSERT IGNORE INTO " . TAB_DSP_DATA_BKT_V . " (interval_start, creative_id, zone_id, dj_win_bid, count, dj_dsp_share, dsp_request_id,  adexchange, impression,display_type) VALUES ('" . implode("','",$impression) . "')");
} else {
error_log(print_r($query_string,true) . " - ELSE - " . $_SERVER["QUERY_STRING"] . " \n",3, 'impression.log');
}
$GLOBALS['db']=null;
header('Content-Type: image/gif');
header('Content-Length: 43');
echo base64_decode('R0lGODlhAQABAIAAAP///wAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==');
